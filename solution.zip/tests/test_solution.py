import unittest, sqlite3, sys, csv
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from analyze import sequence, summarize

class SolutionTests(unittest.TestCase):
    def test_ties_and_first_order(self):
        rows = [dict(customer_id='A',order_id=k,order_date=d,sales='10') for k,d in
                [('z','2020-01-03'),('b','2020-01-01'),('a','2020-01-01')]]
        result=sequence(rows)
        self.assertEqual([r['order_id'] for r in result], ['a','b','z'])
        self.assertEqual([r['days_since_previous'] for r in result], [None,0,2])
        self.assertIsNone(summarize(result)[0]['average_days'])

    def test_duplicate_order_rejected(self):
        r=dict(customer_id='A',order_id='x',order_date='2020-01-01',sales='1')
        with self.assertRaises(ValueError): sequence([r,r])

    def test_sql_bi_matches_python_on_all_source_orders(self):
        with (ROOT/'data/source_orders.csv').open(encoding='utf-8-sig') as f:
            rows=list(csv.DictReader(f))
        db=sqlite3.connect(':memory:')
        db.execute('CREATE TABLE orders_bi(order_id,customer_id,order_date,sales,segment,region)')
        db.executemany('INSERT INTO orders_bi VALUES (?,?,?,?,?,?)',[tuple(r.values()) for r in rows])
        actual=db.execute((ROOT/'sql/repeat_purchases.sql').read_text()).fetchall()
        expected=summarize(sequence(rows))
        for a,e in zip(actual,expected):
            self.assertEqual(a[:2],(e['purchase_number'],e['orders']))
            if a[2] is None:self.assertIsNone(e['average_days'])
            else:self.assertAlmostEqual(a[2],e['average_days'],9)
            self.assertAlmostEqual(a[3],e['average_check'],8)
        self.assertEqual(len(actual),len(expected))
        self.assertEqual(sum(e['orders'] for e in expected),5009)

    def test_paris_sql_zero_years_unknown_loyalty_and_namesakes(self):
        db=sqlite3.connect(':memory:')
        db.executescript('''
        CREATE TABLE Orders(order_id, date, time, "sum", quantity, product_id, client_id, manager_id);
        CREATE TABLE Clients(client_id, reg_date, age, phone, loyalty_id);
        CREATE TABLE Loyalty(loyalty_id, discount, name);
        CREATE TABLE Managers(manager_id, name, grade, city);
        INSERT INTO Managers VALUES (1,'Alice',1,'Paris'),(2,'Alice',1,'Paris'),(3,'Bob',1,'Lyon'),(4,'Zoe',1,'Paris');
        INSERT INTO Clients VALUES (1,'2019-01-01',20,'',1),(2,'2019-01-01',30,'',99);
        INSERT INTO Loyalty VALUES (1,0.1,'Silver');
        INSERT INTO Orders VALUES
        (1,'2020-01-01','12:00',100,2,1,1,1),
        (2,'2020-02-01','12:00',200,3,1,1,1),
        (3,'2021-02-01','12:00',300,1,1,1,3),
        (4,'2021-03-01','12:00',100,1,1,2,2);
        ''')
        rows=db.execute((ROOT/'sql/paris_discounts.sql').read_text()).fetchall()
        self.assertEqual(rows,[(1,'Alice',2020,30.0,0),(1,'Alice',2021,0,0),
                               (2,'Alice',2020,0,0),(2,'Alice',2021,None,1),
                               (4,'Zoe',2020,0,0),(4,'Zoe',2021,0,0)])

if __name__ == '__main__': unittest.main()
