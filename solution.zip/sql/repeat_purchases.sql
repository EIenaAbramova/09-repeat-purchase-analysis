-- SQLite 3. Prepared input: source_orders CSV loaded as orders_bi.
-- The delivered XLSX has one row per unique order (verified before sequencing).
WITH numbered AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY customer_id ORDER BY order_date, order_id
           ) AS purchase_number,
           LAG(order_date) OVER (
               PARTITION BY customer_id ORDER BY order_date, order_id
           ) AS previous_order_date
    FROM orders_bi
), enriched AS (
    SELECT *, CAST(julianday(order_date) - julianday(previous_order_date)
                   AS INTEGER) AS days_since_previous
    FROM numbered
)
SELECT purchase_number, COUNT(*) AS orders,
       AVG(days_since_previous) AS average_days,
       AVG(CAST(sales AS REAL)) AS average_check
FROM enriched
GROUP BY purchase_number
ORDER BY purchase_number;
