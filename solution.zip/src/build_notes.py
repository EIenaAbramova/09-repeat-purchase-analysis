from pathlib import Path
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Cm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
doc=Document()
for st in doc.styles:
    for border in list(st.element.findall('.//' + qn('w:pBdr'))):
        border.getparent().remove(border)
sec=doc.sections[0]
sec.page_height=Cm(29.7);sec.page_width=Cm(21)
sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8)
sec.left_margin=Cm(2.2);sec.right_margin=Cm(2)
normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(11)
normal.paragraph_format.space_after=Pt(7)
normal.paragraph_format.line_spacing=1.12
for name,size in [('Title',25),('Heading 1',17),('Heading 2',13)]:
    st=doc.styles[name];st.font.name='Calibri';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
    st.paragraph_format.space_before=Pt(13);st.paragraph_format.space_after=Pt(8)
    st.paragraph_format.keep_with_next=True
header=sec.header.paragraphs[0];header.text='МАРКЕТПЛЕЙС   /   КОНСПЕКТ РЕШЕНИЯ'
header.runs[0].font.size=Pt(9)
footer=sec.footer.paragraphs[0];footer.alignment=2
footer.add_run('Страница ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
for block in (ROOT/'docs/Конспект.md').read_text(encoding='utf-8').split('\n\n'):
    block=block.strip()
    if not block:continue
    if block.startswith('# '):
        title=doc.add_paragraph(block[2:],style='Title')
        props=title._p.get_or_add_pPr()
        borders=OxmlElement('w:pBdr')
        for side in ['top','left','bottom','right','between','bar']:
            edge=OxmlElement('w:'+side);edge.set(qn('w:val'),'nil');borders.append(edge)
        props.append(borders)
    elif block.startswith('## '):doc.add_paragraph(block[3:],style='Heading 1')
    else:
        text=re.sub(r'`([^`]+)`',r'\1',block.replace('\n',' '))
        doc.add_paragraph(text)
doc.core_properties.title='Маркетплейс разбор тестового задания'
doc.core_properties.subject='BI анализ повторных покупок и SQL по скидкам'
doc.core_properties.author=''
doc.save(ROOT/'docs/Конспект.docx')
print(ROOT/'docs/Конспект.docx')
