"""Rebuild from supplied XLSX or the published minimal CSV extract."""
from pathlib import Path
from collections import defaultdict, Counter
from datetime import date, timedelta
from decimal import Decimal
import csv, json, hashlib, argparse, statistics

ROOT = Path(__file__).resolve().parents[1]

def sequence(rows):
    out = []
    clients = defaultdict(list)
    seen = set()
    for r in rows:
        if r['order_id'] in seen:
            raise ValueError('Expected one row per order: ' + r['order_id'])
        seen.add(r['order_id'])
        clients[r['customer_id']].append(r)
    for customer, orders in sorted(clients.items()):
        previous = None
        for number, r in enumerate(sorted(orders, key=lambda r: (r['order_date'], r['order_id'])), 1):
            current = date.fromisoformat(r['order_date'])
            out.append({**r, 'purchase_number': number,
                        'previous_order_date': previous.isoformat() if previous else '',
                        'days_since_previous': (current - previous).days if previous else None})
            previous = current
    return out

def summarize(rows):
    groups = defaultdict(list)
    for r in rows:
        groups[r['purchase_number']].append(r)
    return [dict(purchase_number=n, orders=len(rs),
                 sales=float(sum((Decimal(str(r['sales'])) for r in rs), Decimal(0))),
                 average_check=float(sum((Decimal(str(r['sales'])) for r in rs), Decimal(0))/len(rs)),
                 average_days=statistics.mean([r['days_since_previous'] for r in rs]) if n > 1 else None,
                 median_days=statistics.median([r['days_since_previous'] for r in rs]) if n > 1 else None)
            for n, rs in sorted(groups.items())]

def write_csv(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path)
    args = parser.parse_args()
    if args.source:
        import openpyxl
        w = openpyxl.load_workbook(args.source, read_only=True, data_only=True)
        values = iter(w.active.values)
        header = next(values)
        raw = [dict(zip(header, r)) for r in values if any(v is not None for v in r)]
        rows = []
        for r in raw:
            dt = r['Order Date']
            if isinstance(dt, (int, float)):
                dt = date(1899, 12, 30) + timedelta(days=dt)
            else:
                dt = dt.date() if hasattr(dt, 'date') else dt
            rows.append(dict(order_id=r['Order ID'], customer_id=r['Customer ID'],
                             order_date=dt.isoformat(), sales=str(r['Sales']),
                             segment=r['Segment'], region=r['Region']))
        # Do not publish names, addresses or irrelevant source columns.
        write_csv(ROOT/'data/source_orders.csv', rows)
        source_sha = hashlib.sha256(args.source.read_bytes()).hexdigest()
    else:
        with (ROOT/'data/source_orders.csv').open(encoding='utf-8-sig') as f:
            rows = list(csv.DictReader(f))
        source_sha = None
    orders = sequence(rows)
    summary = summarize(orders)
    write_csv(ROOT/'data/orders_enriched.csv', orders)
    write_csv(ROOT/'data/purchase_summary.csv', summary)
    first = [r for r in orders if r['purchase_number'] == 1]
    repeat = [r for r in orders if r['purchase_number'] > 1]
    same_day = sum(r['days_since_previous'] == 0 for r in repeat)
    checks = dict(orders=len(orders), customers=len(first), repeat_orders=len(repeat),
                  customers_with_repeat=sum(r['purchase_number'] == 2 for r in orders),
                  first_date=min(r['order_date'] for r in orders), last_date=max(r['order_date'] for r in orders),
                  total_sales=float(sum((Decimal(r['sales']) for r in orders), Decimal(0))),
                  average_repeat_days=statistics.mean(r['days_since_previous'] for r in repeat),
                  same_day_repeat_orders=same_day, max_purchase_number=max(r['purchase_number'] for r in orders),
                  source_xlsx_sha256=source_sha)
    assert sum(g['orders'] for g in summary) == len(rows)
    assert len(first) + len(repeat) == len(rows)
    assert all(r['days_since_previous'] is None or r['days_since_previous'] >= 0 for r in orders)
    for r in orders:
        r['sales'] = float(r['sales'])
    payload = json.dumps(dict(orders=orders, checks=checks), ensure_ascii=False).replace('</', '<\\/')
    template = (ROOT/'src/report_template.html').read_text(encoding='utf-8')
    (ROOT/'Report.html').write_text(template.replace('__PAYLOAD__', payload), encoding='utf-8')
    (ROOT/'data/checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(checks, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
