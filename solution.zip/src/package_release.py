from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
PUB=ROOT.parent/'GitHub'/'marketplace-repeat-purchases'
PUB.mkdir(parents=True,exist_ok=True)
copies={'README.md':'README.md','Report.html':'Report.html',
        'docs/Конспект.md':'Конспект.md','docs/Конспект.docx':'Конспект.docx',
        'docs/PowerBI.md':'PowerBI.md','sql/paris_discounts.sql':'paris_discounts.sql',
        'data/purchase_summary.csv':'purchase_summary.csv','data/checks.json':'checks.json'}
for source,target in copies.items():shutil.copy2(ROOT/source,PUB/target)
report=(PUB/'Report.html').read_text(encoding='utf-8')
report=report.replace('href="sql/paris_discounts.sql"','href="paris_discounts.sql"').replace('href="docs/Конспект.md"','href="Конспект.md"')
(PUB/'Report.html').write_text(report,encoding='utf-8')
with ZipFile(PUB/'solution.zip','w',ZIP_DEFLATED) as z:
    for f in sorted(ROOT.rglob('*')):
        if f.is_file() and not any(p in {'qa','__pycache__','.git'} for p in f.relative_to(ROOT).parts):
            z.write(f,f.relative_to(ROOT).as_posix())
manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in PUB.iterdir() if f.is_file() and f.name!='SHA256.json'}
(PUB/'SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({f.name:f.stat().st_size for f in PUB.iterdir() if f.is_file()},ensure_ascii=False,indent=2))
